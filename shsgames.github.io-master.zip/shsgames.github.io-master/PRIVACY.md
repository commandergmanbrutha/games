# Privacy Statement
Your privacy and security are important to us. SHS Games was founded on being open & transparent to its users.

## Data Collection
All data collected is completely annonymous. No Personal Identifiable Information (PII) is collected. The data we collect is purely to enhance the quality and performance of SHS Games. The information collected is to determine which games are the most popular and which ones aren't.

We thank you for your continued trust in our open source services.